WILD = {}
WILD.CurrentRequestId          = 0
WILD.ServerCallbacks           = {}

WILD.TriggerServerCallback = function(name, cb, ...)
	WILD.ServerCallbacks[WILD.CurrentRequestId] = cb

	TriggerServerEvent('WILD:triggerServerCallback', name, WILD.CurrentRequestId, ...)

	if WILD.CurrentRequestId < 65535 then
		WILD.CurrentRequestId = WILD.CurrentRequestId + 1
	else
		WILD.CurrentRequestId = 0
	end
end

RegisterNetEvent('WILD:serverCallback')
AddEventHandler('WILD:serverCallback', function(requestId, ...)
	WILD.ServerCallbacks[requestId](...)
	WILD.ServerCallbacks[requestId] = nil
end)