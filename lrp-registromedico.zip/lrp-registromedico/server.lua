local Tunnel = module("vrp", "lib/Tunnel")
local Proxy = module("vrp", "lib/Proxy")

vRPclient = Tunnel.getInterface("vRP", "dit_script") 
vRP = Proxy.getInterface("vRP")

local colors = {
	[0] = 'Negro',
	[1] = 'Negro',
	[2] = 'Negro',
	[55] = 'Negro',
	[56] = 'Negro',
	[57] = 'Negro',
	[58] = 'Negro',
	[59] = 'Negro',
	[60] = 'Negro',
	[61] = 'Negro',
	[3] = 'Marrón',
	[4] = 'Marrón',
	[5] = 'Marrón',
	[6] = 'Marrón',
	[7] = 'Marrón',
	[8] = 'Marrón',
	[9] = 'Rubi@',
	[10] = 'Rubi@',
	[11] = 'Rubi@',
	[12] = 'Rubi@',
	[13] = 'Rubi@',
	[14] = 'Rubi@',
	[15] = 'Rubi@',
	[16] = 'Rubi@',
	[62] = 'Rubi@',
	[63] = 'Rubi@',
	[26] = 'Gris',
	[27] = 'Gris',
	[28] = 'Gris',
	[29] = 'Gris',
	[30] = 'Morado',
	[31] = 'Morado',
	[32] = 'Morado',
	[33] = 'Rosado',
	[34] = 'Rosado',
	[35] = 'Rosado',
	[36] = 'Turquesa',
	[37] = 'Turquesa',
	[38] = 'Turquesa',
	[39] = 'Verde',
	[40] = 'Verde',
	[41] = 'Verde',
	[42] = 'Verde',
	[43] = 'Verde',
	[44] = 'Verde',
	[45] = 'Amarillo',
	[46] = 'Amarillo',
	[47] = 'Naranja',
	[48] = 'Naranja',
	[49] = 'Naranja',
	[51] = 'Naranja',
	[52] = 'Naranja'
}
local letter   = {'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'X', 'Y'}

RegisterCommand("mdtems", function(source)
  local user_id = vRP.getUserId({source})
    if vRP.hasGroup({user_id, config.job}) then
      TriggerClientEvent("mdtems:permok", source)
    else
      print("Du ikke ems")
    end
end)

math.randomseed(os.time())

-- Fetch
WILD.RegisterServerCallback('lrp-registromedico:fetch', function( source, cb, data, type )
  if type == 'start' then
    MySQL.Async.fetchAll('SELECT date, offense, institution, charge, term, classified FROM lrp_registromedico', {},
    function (result)
      cb(result)
    end)
  elseif type == 'record' then
    MySQL.Async.fetchAll('SELECT * FROM lrp_registromedico WHERE offense = @offense', {['@offense'] = data.offense},
    function (resultRecord)
			if resultRecord[1] ~= nil then
	      MySQL.Async.fetchAll('SELECT firstname, name, sex FROM lrp_registromedicoinfo WHERE user_id = @user_id', {['@user_id'] = resultRecord[1].user_id},
	      function (resultUser)
	        local array = {
	          userinfo = resultUser,
	          records = resultRecord
	        }
	        cb(array)
	      end)
			else
				cb('error')
			end
    end)
  elseif type == 'user' then
    MySQL.Async.fetchAll('SELECT * FROM lrp_registromedicoinfo WHERE age = @age', {['@age'] = data.age},
    function (resultUser)
      MySQL.Async.fetchAll('SELECT * FROM lrp_registromedico WHERE user_id = @user_id', {['@user_id'] = resultUser[1].user_id},
      function (resultRecord)
        local array = {
          userinfo = resultUser,
          records = resultRecord
        }
        cb(array)
      end)
    end)
  end
end)

-- Search
WILD.RegisterServerCallback('lrp-registromedico:search', function( source, cb, data )
  local query    = 'SELECT * FROM lrp_registromedicoinfo'
  local queryVal = nil

  if string.len(data.age) > 0 then
    query    = 'SELECT * FROM lrp_registromedicoinfo WHERE age = @x'
    queryVal = data.age
  elseif string.len(data.firstname) > 0 then
    query = 'SELECT * FROM lrp_registromedicoinfo WHERE firstname = @x'
    queryVal = data.firstname
  elseif string.len(data.name) > 0 then
    query = 'SELECT * FROM lrp_registromedicoinfo WHERE name = @x'
    queryVal = data.name
  

  elseif string.len(data.offense) > 0 then
		cb('ok')
  end

  if queryVal == nil then
    MySQL.Async.fetchAll(query, {},
     function (result)
       if result[1] ~= nil then
		cb(result)
       else
         cb('error')
       end
     end)
   else
     MySQL.Async.fetchAll(query, {['@x'] = queryVal},
      function (result)
        if result[1] ~= nil then
          cb(result)
        else
          cb('error')
        end
      end)
   end
end)

-- Add
WILD.RegisterServerCallback('lrp-registromedico:add', function( source, cb, data )
  local recordid = letter[math.random(1,6)] .. math.random(0,999) .. letter[math.random(1,6)] .. math.random(0,999)
  local weight   = 0
  local warden = vRP.getUserId({source})

  local date    = data.date
  local offense = letter[math.random(1,6)] .. '-' .. math.random(100,999)

  if date == 'Today' then
    date = os.date('%Y-%m-%d')
  end

  MySQL.Async.fetchAll('SELECT firstname FROM vrp_user_identities WHERE user_id = @user_id', {['@user_id'] = warden},
  function (result)
    warden = result[1].firstname
  end)


  MySQL.Async.fetchAll('SELECT user_id, registration, age, phone FROM vrp_user_identities WHERE UPPER(firstname) = @firstname AND UPPER(name) = @name AND age = @age', {['@firstname'] = data.firstname, ['@name'] = data.name, ['@age'] = data.age},
  function (result)
    if result[1] ~= nil then
      local user_id = result[1].user_id

      if result[1].sex == 'M' then
       if tonumber(result[1].age) < 170 then
         weight = math.random(52,65)
       else
         weight = math.random(65,90)
       end
      else
        if tonumber(result[1].age) < 170 then
         weight = math.random(49,61)
        else
         weight = math.random(61,85)
        end
      end

      MySQL.Async.fetchAll('SELECT user_id FROM lrp_registromedicoinfo WHERE user_id = @user_id', {['@user_id'] = user_id},
      function (resultCheck)
        if resultCheck[1] == nil then
          MySQL.Async.execute('INSERT INTO lrp_registromedicoinfo (user_id, aliases, recordid, weight, eyecolor, haircolor, firstname, name, age, sex, height) VALUES (@user_id, @aliases, @recordid, @weight, @eyecolor, @haircolor, @firstname, @name, @age, @sex, @height)',
           {
             ['@user_id'] = user_id,
             ['@aliases']    = data.firstname,
             ['@recordid']   = recordid,
             ['@weight']     = weight .. 'kg',
             ['@eyecolor']   = "Brun",
             ['@haircolor']  = "Lyst",
             ['@firstname']  = data.firstname,
             ['@name']   = data.name,
             ['@age']        = data.age,
           },
           function (rowsChanged)
             MySQL.Async.execute('INSERT INTO lrp_registromedico (offense, date, institution, charge, description, term, classified, user_id, age, warden) VALUES (@offense, @date, @institution, @charge, @description, @term, @classified, @user_id, @age, @warden)',
              {
                ['@offense']     = offense,
                ['@date']        = date,
                ['@institution'] = 'PILLBOX HOSPITAL',
                ['@charge']      = data.charge,
                ['@description'] = data.description,
                ['@term']        = data.term,
                ['@classified']  = 0,
                ['@user_id']  = user_id,
                ['@age']         = data.age,
                ['@warden']      = warden
              },
              function (rowsChanged)
                MySQL.Async.fetchAll('SELECT * FROM lrp_registromedico WHERE offense = @offense', {['@offense'] = offense},
                 function (result)
                   if result[1] ~= nil then
                     MySQL.Async.fetchAll('SELECT * FROM lrp_registromedicoinfo WHERE UPPER(firstname) = @firstname AND UPPER(name) = @name AND age = @age', {['@firstname'] = data.firstname, ['@name'] = data.name, ['@age'] = data.age},
                      function (uinfo)
                        if uinfo[1] ~= nil then
                          local array = {
                            userinfo = uinfo,
                            records = result
                          }

                          cb(array)
                        end
                      end)
                   end
                 end)
             end)
          end)
        else
          MySQL.Async.execute('INSERT INTO lrp_registromedico (offense, date, institution, charge, description, term, classified, user_id, age, warden) VALUES (@offense, @date, @institution, @charge, @description, @term, @classified, @user_id, @age, @warden)',
           {
             ['@offense']     = offense,
             ['@date']        = date,
             ['@institution'] = 'PILLBOX HOSPITAL',
             ['@charge']      = data.charge,
             ['@description'] = data.description,
             ['@term']        = data.term,
             ['@classified']  = 0,
             ['@user_id']  = user_id,
             ['@age']         = data.age,
             ['@warden']      = warden
           },
           function (rowsChanged)
             MySQL.Async.fetchAll('SELECT * FROM lrp_registromedico WHERE offense = @offense', {['@offense'] = offense},
              function (result)
                if result[1] ~= nil then
                  MySQL.Async.fetchAll('SELECT * FROM lrp_registromedicoinfo WHERE UPPER(firstname) = @firstname AND UPPER(name) = @name AND age = @age', {['@firstname'] = data.firstname, ['@name'] = data.name, ['@age'] = data.age},
                   function (uinfo)
                     if uinfo[1] ~= nil then
                       local array = {
                         userinfo = uinfo,
                         records = result
                       }
                       cb(array)
                     end
                   end)
                end
              end)
          end)
        end
      end)
     else
       cb('error')
     end
   end)
end)

-- Update
WILD.RegisterServerCallback('lrp-registromedico:update', function( source, cb, data )
	if data.description ~= nil then
	  MySQL.Async.execute('UPDATE lrp_registromedico SET description = @description WHERE offense = @offense', {['@description'] = data.description, ['@offense'] = data.offense})
	  cb('ok')
	elseif data.classified ~= nil then
		MySQL.Async.execute('UPDATE lrp_registromedico SET classified = @classified WHERE offense = @offense', {['@classified'] = data.classified, ['@offense'] = data.offense})
 	 	cb('ok')
	end
end)

-- Remove
WILD.RegisterServerCallback('lrp-registromedico:remove', function( source, cb, data )
  MySQL.Async.fetchAll('SELECT user_id FROM lrp_registromedico WHERE offense = @offense', {['@offense'] = data.offense},
  function (resultID)
    MySQL.Async.fetchAll('SELECT * FROM lrp_registromedico WHERE user_id = @user_id', {['@user_id'] = resultID[1].user_id},
    function (resultAll)
      if #resultAll < 2 then
        MySQL.Async.execute('DELETE FROM lrp_registromedicoinfo WHERE user_id = @user_id',{ ['@user_id'] = resultID[1].user_id})
        MySQL.Async.execute('DELETE FROM lrp_registromedico WHERE offense = @offense',{ ['@offense'] = data.offense})
      else
        MySQL.Async.execute('DELETE FROM lrp_registromedico WHERE offense = @offense',{ ['@offense'] = data.offense})
      end
      cb('ok')
    end)
  end)
end)
